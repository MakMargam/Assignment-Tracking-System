//$(document).ready(function () {
//    $("#sub").click(function () {
//
//        event.preventDefault();
//        var formData = new FormData();
//        $.each($('#files')[0].files, function (key, value) {
//            formData.append(key, value);
//        });
//        console.log($('#files')[0].files);
//
//        $.ajax({
//            type: 'POST',
//            // enctype: 'multipart/form-data',
//            url: "http://localhost:8080/upload",
//            processData: false, //prevent jQuery from automatically transforming the data into a query string
//            contentType: false,
//            cache: false,
//            timeout: 600000,
//            data: {
//                files: formData,
//            },
//            success: function (data) {
//                
//                // console.log(data);
//            },
//            error: function (err) {
//                // console.log(err);
//            }
//        });
//    });
//});