/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.demofile;

import com.mycompany.demofile.Controller.FileUploadController;
import java.io.File;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 *
 * @author abhay
 */
@SpringBootApplication
@ComponentScan({"com.mycompany.demofile", "com.mycompany.demofile.Controller"})
public class Application {
    public static void main(String[] args) {
        new File(FileUploadController.uploadDirectory).mkdir();
        SpringApplication.run(Application.class, args);
    }
}
